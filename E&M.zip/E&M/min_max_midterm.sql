SELECT MIN(goals) as leastGoals,
		MAX(goals) as mostGoals
FROM EquiPlay.PlayerPerformance;
