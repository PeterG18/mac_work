SELECT * FROM EquiPlay.InjuryReport
WHERE injury_type IS NOT NULL;