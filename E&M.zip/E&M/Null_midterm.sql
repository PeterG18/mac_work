SELECT * FROM EquiPlay.InjuryReport
WHERE injury_type IS NULL;