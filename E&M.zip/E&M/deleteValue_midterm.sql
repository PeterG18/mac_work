USE Equiplay;
DELETE FROM InjuryReport 
WHERE injury_type = 'dead leg';