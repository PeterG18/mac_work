SELECT * FROM sakila.payment;
SELECT AVG(amount) FROM sakila.payment;
SELECT AVG(DISTINCT amount) FROM sakila.payment;

#SELECT COUNT(*) FROM sakila.payment;
#SELECT COUNT(amount) FROM sakila.payment;
#SELECT COUNT(DISTINCT amount) FROM sakila.payment;

