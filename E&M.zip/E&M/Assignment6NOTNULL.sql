SELECT LocalName FROM world.country
WHERE IndepYear is NOT NULL;