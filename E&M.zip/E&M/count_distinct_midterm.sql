SELECT COUNT(company) AS companyDeals,
	   COUNT(distinct company) AS diffCompanies
FROM Equiplay.NIL_deals;
