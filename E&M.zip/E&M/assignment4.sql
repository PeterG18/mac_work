#SELECT AVG(amount) FROM sakila.payment;

#SELECT SUM(amount) FROM sakila.payment;

#SELECT COUNT(amount) FROM sakila.payment;

SELECT COUNT(DISTINCT amount) FROM sakila.payment;


