USE Equiplay;
INSERT INTO InjuryReport (injury_id, athlete_id, injury_type) 
VALUES (4,2,'dead leg');