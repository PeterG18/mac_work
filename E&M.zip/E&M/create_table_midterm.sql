USE Equiplay;
CREATE TABLE InjuryReport 
(injury_id INT PRIMARY KEY, athlete_id INT, injury_type VARCHAR(45));

