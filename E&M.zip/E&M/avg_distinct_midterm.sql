SELECT AVG(goals) as AvgGoals,
	   AVG(distinct goals) as diffAvgGoals
FROM EquiPlay.PlayerPerformance;